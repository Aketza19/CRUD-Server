package myapplication.entity;

/**
 *
 * @author Mikel
 */
public enum UserPrivilege {

    SUPERUSER,
    PROVIDER,
    WORKER,
}
