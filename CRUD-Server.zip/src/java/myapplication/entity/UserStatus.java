package myapplication.entity;

/**
 *
 * @author Mikel
 */

public enum UserStatus {

    ENABLED, 
    DISABLED, 
}